package Resources;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class base {
	
	public WebDriver driver; 
	//public Properties prop;
	public WebDriver initializeDriver() throws IOException
	{
		//chrome
		//
		//WebDriver
		Properties prop = new Properties();
		//FileInputStream fis=new FileInputStream("C:\\Users\\Revo Laptop 03\\RevopayProject\\src\\main\\java\\Revopay\\data.properties");
		FileInputStream fis=new FileInputStream("C:\\Users\\Revo Laptop 03\\RevopayProject\\src\\main\\java\\Resources\\data.properties");
		prop.load(fis);  
		String browserName=prop.getProperty("browsers");
		//String URLName=prop.getProperty("url");
		
		if(browserName.equals("chrome"));
		{
			// execute in chrome driver
			System.setProperty("webdriver.chrome.driver", "Drivers//chromedriver.exe");
			driver = new ChromeDriver();
			//driver.manage().window().maximize();
			//driver.get("https://sandbox.revopay.com/login");  //sandbox  vkatikaneni:test1234
			//driver.get(browserName=prop.getProperty("url")); //qa3 dberman:Password1
		}
		
		
		if(browserName.equals("firefox"))
		{
			// execute in firefox driver			
			//System.setProperty("webdriver.chrome.driver", "Drivers//chromedriver.exe");
			driver = new FirefoxDriver();
		}
		
		if(browserName.equals("IE"))
		{
			// execute in IE driver
			//System.setProperty("webdriver.chrome.driver", "Drivers//chromedriver.exe");
			//driver = new ChromeDriver();
		}
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return driver;
	}

}
