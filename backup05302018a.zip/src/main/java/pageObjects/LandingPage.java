package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {
	
	public WebDriver driver;
	
	By LogoutButton = By.cssSelector(".a_action_logout");
	By Dashboard = By.xpath("//*[@id='side-menu']/li[1]/a/span[1]");
	By Reports = By.xpath("//*[@id='side-menu']/li[2]/a/span[1]");
	By Manage = By.xpath("//*[@id='side-menu']/li[3]/a/span[1]");
	By ManageMerchants = By.cssSelector(".in > li:nth-child(4) > a:nth-child(1)");
	By title = By.xpath("//*[@id='logo']/span");
	//By PanelHeader = By.xpath("//*[@id='wrapper']/div/div[2]/div[1]/div/div/div[1]");
	By PanelHeader = By.xpath(".col-lg-12 > div:nth-child(1) > div:nth-child(1)");
	
	

	
	public LandingPage(WebDriver driver)
	{
		//return driver.findElement(signin);
		this.driver=driver;
	}
	
	public WebElement LogoutButton()
	{
		return driver.findElement(LogoutButton);
	}

	public WebElement Dashboard()
	{
		return driver.findElement(Dashboard);
	}

	public WebElement Reports()
	{
		return driver.findElement(Reports);
	}
	
	public WebElement Manage()
	{
		return driver.findElement(Manage);
	}

	public WebElement ManageMerchants()
	{
		return driver.findElement(ManageMerchants);
	}
	
	public WebElement title()
	{
		return driver.findElement(title);
	}

	public WebElement PanelHeader()
	{
		return driver.findElement(PanelHeader);
	}
	
	
//	public WebElement Application()
//	{
//		return driver.findElement(Application);
//	}
//	
//	public WebElement SupportMenu()
//	{
//		return driver.findElement(SupportMenu);
//	}
//
//	public WebElement SearchByMerchant()
//	{
//		return driver.findElement(SearchByMerchant);
//	}

}

