package Revopay;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.testng.annotations.Test;

import Resources.base;
import pageObjects.LandingPage;
//import pageObjects.LoginPage;

public class ValidateTitle extends base
{

	@Test
	
	public void basePageNavigation2() throws IOException, InterruptedException
	{
		
		HomePage h = new HomePage();
		h.basePageNavigation("dberman", "Password1");
		
		//driver=initializeDriver();
		//driver.get("https://qa3-admin-app.revopay.com/");
		
		//LoginPage l = new LoginPage(driver);
		//l.getUsername().sendKeys(username);
		//l.getPassword().sendKeys(password);
		//System.out.println(text);
		//l.getLoginButton().click();
		
		
		// Work on this
		LandingPage lp2 = new LandingPage(h.driver);
		System.out.println(lp2.title().getText());
		//System.out.println(prop.getProperty("url"));
		String x = h.prop.getProperty("url");
		System.out.println(x);
		//assert.assertEquals(lp2.title().getText(), 'Master Toolbox');
		String LandingPageTitle = lp2.title().getText();
		//assert.assertEquals(LandingPageTitle, "Master Toolbox");
		assertEquals(LandingPageTitle, "Master Toolbox");

		
		//LandingPage lp = new LandingPage(driver);
		lp2.Dashboard().click();
		lp2.Reports().click();
		Thread.sleep(1000);  // needed to put in delay.  Otherwise, Manage below doesn't expand.
		lp2.Manage().click();
		lp2.ManageMerchants().click();
		
		
		//Thread.sleep(2000);
		//lp2.Manage().click();
		
		
		
		
		
		//System.out.println(lp2.title().getText());
		//lp2.Reports().click();
		//lp2.Manage().click();
		//System.out.println(lp.getTitle().getText());
		//driver.getTitle()
		
		
//		
//		
//		
//		LoginPage l = new LoginPage(driver);
//		l.getUsername().sendKeys(username);
//		l.getPassword().sendKeys(password);
//		//System.out.println(text);
//		l.getLoginButton().click();
//
//		lp.Dashboard().click();
//		lp.Reports().click();
	}
	
	
}
