package Revopay;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
//import java.util.logging.Logger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Resources.base;
import pageObjects.LandingPage;
//import pageObjects.LoginPage;

public class ValidateTitle extends base
{
	public static Logger log = LogManager.getLogger(base.class.getName());

public HomePage h;	
public LandingPage lp2;

//	@BeforeTest
//	public void hellotester() throws IOException, InterruptedException
//	{
//		//System.out.println("Hello Tester - you can put your cleanup code in this block.");
//		h = new HomePage();
//		h.basePageNavigation("dberman", "Password1");
//		lp2 = new LandingPage(h.driver);
//	}
	
	
	
	
	@Test
	
	public void basePageNavigation2() throws IOException, InterruptedException
	{
		
		h = new HomePage();
		h.basePageNavigation("dberman", "Password1");
		log.info("Driver is initialized");
		lp2 = new LandingPage(h.driver);
		log.info("LandingPage is Loaded");
		
		//driver=initializeDriver();
		//driver.get("https://qa3-admin-app.revopay.com/");
		
		// Work on this
		
		System.out.println(lp2.title().getText());
		log.info("Get Title of LandingPage: " + lp2.title().getText());
		//System.out.println(prop.getProperty("url"));
		String x = h.prop.getProperty("url");
		System.out.println(x);
		//assert.assertEquals(lp2.title().getText(), 'Master Toolbox');
		String LandingPageTitle = lp2.title().getText();
		//assert.assertEquals(LandingPageTitle, "Master Toolbox");
        Assert.assertEquals(LandingPageTitle, "Master Toolbox");
        
        if (LandingPageTitle.equals("Master Toolbox"))
        {
        	System.out.println("pass " + LandingPageTitle + " = Master Toolbox");
        	log.info("pass " + LandingPageTitle + " = Master Toolbox");
        }
        else
        {
        	System.out.println("fail " + LandingPageTitle + " != Master Toolbox");
        	log.error("fail " + LandingPageTitle + " = Master Toolbox");
        }
        
        //Assert.assertTrue(LandingPageTitle==="Master Toolbox", "AssertTrue");

		
		//Assert.assertTrue(LandingPageTitle, "Master Toolbox");
		
		log.info("Assertion Passed");

		
		//LandingPage lp = new LandingPage(driver);
		lp2.Dashboard().click();
		lp2.Reports().click();
		Thread.sleep(1000);  // needed to put in delay.  Otherwise, Manage below doesn't expand.
		lp2.Manage().click();
		lp2.ManageMerchants().click();
		//h.driver.close();
		//h.driver=null;

	}
	

//	@Test
//	
//	public void basePageNavigation3() throws IOException, InterruptedException
//	{
//		
//		h = new HomePage();
//		h.basePageNavigation("dberman", "Password1");
//		lp2 = new LandingPage(h.driver);
//		
//		//driver=initializeDriver();
//		//driver.get("https://qa3-admin-app.revopay.com/");
//		
//		// Work on this
//		LandingPage lp2 = new LandingPage(h.driver);
//		System.out.println(lp2.title().getText());
//		//System.out.println(prop.getProperty("url"));
//		String x = h.prop.getProperty("url");
//		System.out.println(x);
//		//assert.assertEquals(lp2.title().getText(), 'Master Toolbox');
//		String LandingPageTitle = lp2.title().getText();
//		Assert.assertEquals(LandingPageTitle, "Master Toolbox");
//		//Assert.assertFalse(true);
//		// commented out because causes exception which may block @AfterTest from executing
//		//assertEquals(LandingPageTitle, "Master Toolbox123");
//		
//
//		
//		//LandingPage lp = new LandingPage(driver);
//		lp2.Dashboard().click();
//		lp2.Reports().click();
//		Thread.sleep(1000);  // needed to put in delay.  Otherwise, Manage below doesn't expand.
//		lp2.Manage().click();
//		lp2.ManageMerchants().click();
//		//h.driver.close();
//		//h.driver=null;
//        
//		log.info("End of ValidateTitle Test");
//	}

//	@AfterTest
//	public void cleanup()
//	{
//		h.driver.quit();
//	}

	
}
