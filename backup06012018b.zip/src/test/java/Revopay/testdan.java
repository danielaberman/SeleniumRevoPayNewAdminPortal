package Revopay;

import java.io.IOException;

import Resources.base;

public class testdan {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		System.out.println("begin");
		base b = new base();
		b.getScreenshot("hello");
		System.out.println("end");

	}

}
